﻿using Sybrin.Extensions;
using Sybrin10.Kernel;
using System;
using System.Diagnostics;

namespace $safeprojectname$ {
    public static class Extensions {
        public static string LogInfo = "$safeprojectname$";
        public static string LogError = "$safeprojectname$.Exceptions";
        public static ILogger Logger { get; set; }

        public static void CustomLog(this string message, EntryType type = EntryType.Debug, Exception ex = null) {
            message.SimpleLog((type == EntryType.Error || ex != null) ? LogError : LogInfo, type);
            Logger?.Write(LogInfo, message, type, ex);
        }

        public static void CustomLog(this Exception ex, string message = "") {
            ex.HandleException(message);
        }

        public static void HandleException(this Exception ex, string message = "", bool showMessage = false,
            bool throwException = false) {
            var methodName = new StackTrace().GetFrame(1).GetMethod().Name;
            var type = new StackTrace().GetFrame(1).GetMethod().ReflectedType;
            var newMessage = $"{ex.GetType().FullName} - Additional Information: '{(message == "" ? "None" : message)}' [Executed in {type} - {methodName}], Exception Message: '{ex.Message}'";
            var innerEx = ex.InnerException;
            var prefix = " >>";
            while (innerEx != null) {
            newMessage += $"\n {prefix} Inner Exception: {innerEx.Message}";
                innerEx = innerEx.InnerException;
            }

            newMessage.SimpleLog(LogError, EntryType.Error);

            if (throwException)
                throw ex;
        }
    }
}
